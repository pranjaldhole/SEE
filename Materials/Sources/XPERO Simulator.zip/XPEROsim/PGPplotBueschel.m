function PGPplotBueschel(Ppose,Ptheta,Pradius,Pthinout,Ppltsym)
%function PGPplotBueschel(Ppose,Ptheta,Pradius,Pthinout,Ppltsym)
%[1,3]=size(Ppose)
N=max(2,length(Pradius));
cart=zeros(2,N);
theta=Ptheta+Ppose(3);
[cartX,cartY]=pol2cart(theta,Pradius);
cart=[cartX;cartY];
startpoints=repmat(transpose(Ppose(1:2)),1,N);
endpoints=cart+startpoints;
allpoints=[transpose(startpoints) transpose(endpoints)];
tmp=transpose(allpoints);
plotptsX=tmp(1:2*Pthinout:end);
plotptsY=tmp(2:2*Pthinout:end);
plot(plotptsX,plotptsY,Ppltsym);
return;