%test_PGPcentroid
%$Log$
%$Id$
%global setup
clear;
close;
clear global;
testname     = 'PGPcentroid';

%setup test 1
%
testnumber   = 1;
fprintf('Start:<%s> No.<%d>: ',testname,testnumber)
% a test for non connected polygons
mylines=[0 0 1 0; 1 0 1 1 ;1 1 0 1; 0 1 0 0];
myexpectedresu=[1,0.5,0.5];
%do test
myresu=zeros(1,3);
myresu = PGPcentroid(mylines);
%check test result
%return value1 is wrong
if find(abs(myresu - myexpectedresu) > eps) %return value is wrong
	 fprintf('\n%s: Test No. %d ERROR: some case differs from expected ',testname,testnumber);
     myresu
     return;
%all OK
else    
  fprintf('OK\n',testname,testnumber);
  testnumber = testnumber+1;
end
%tear down test
clear myresu;
clear myexpectedresu;

%%%%%%%%%
fprintf('EOT:<%s>\n',testname)
%EOT all
