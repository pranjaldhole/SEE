%test_PGPviewDistance2
%$Log$
%$Id$

clear;
close all;

myrobpose = [0 0 0];
myroom = PGPreadPolygon('cage.txt'); % all in cms
myRobo = PGPreadPolygon('nxt_robot.txt');
miregal={};
%%
mydirs=linspace(-pi/2,pi/2,180);
alldist=zeros(0,length(mydirs));
%% mark exit on diagramm
miregal{1}=[[0 85 0 115];[0 115 0 85]]; %exit
%% block exit once
tmppoly = PGPreadPolygon('blackbox1.txt');
I = eye(2,2);
rot=[cos(pi/4) sin(pi/4); -sin(pi/4) cos(pi/4)];
polyrot = kron(I,rot);%chess board matrix along diagonal
tmppoly=polyrot*transpose(tmppoly);
tmppoly=tmppoly+repmat([30;70;30;70],1,4);
miregal{2}=transpose(tmppoly);
%% block exit twice
tmppoly = PGPreadPolygon('blackbox1.txt');
I = eye(2,2);
rot=[cos(pi/4) sin(pi/4); -sin(pi/4) cos(pi/4)];
polyrot = kron(I,rot);%chess board matrix along diagonal
tmppoly=polyrot*transpose(tmppoly);
tmppoly=tmppoly+repmat([30;115;30;115],1,4);
miregal{3}=transpose(tmppoly);
%% block fake exit 1 
tmppoly = PGPreadPolygon('blackbox1.txt');
I = eye(2,2);
rndrot=2*pi*rand(1,1);
rot=[cos(rndrot) sin(rndrot); -sin(rndrot) cos(rndrot)];
polyrot = kron(I,rot);%chess board matrix along diagonal
tmppoly=polyrot*transpose(tmppoly);
tmppoly=tmppoly+repmat([100;30;100;30],1,4);
miregal{4}=transpose(tmppoly);
%% block fake exit 2 
tmppoly = PGPreadPolygon('blackbox1.txt');
I = eye(2,2);
rndrot=2*pi*rand(1,1);
rot=[cos(rndrot) sin(rndrot); -sin(rndrot) cos(rndrot)];
polyrot = kron(I,rot);%chess board matrix along diagonal
tmppoly=polyrot*transpose(tmppoly);
tmppoly=tmppoly+repmat([170;100;170;100],1,4);
miregal{5}=transpose(tmppoly);
%% block fake exit 3 
tmppoly = PGPreadPolygon('blackbox1.txt');
I = eye(2,2);
rndrot=2*pi*rand(1,1);
rot=[cos(rndrot) sin(rndrot); -sin(rndrot) cos(rndrot)];
polyrot = kron(I,rot);%chess board matrix along diagonal
tmppoly=polyrot*transpose(tmppoly);
tmppoly=tmppoly+repmat([100;170;100;170],1,4);
miregal{6}=transpose(tmppoly);
%%myExcludeBox = PGPreadPolygon('greenbox.txt');
alldist=zeros(1,1*length(mydirs));
for k=1:1
%[miregal{4},Rpose]=PGPlegalRandomRobotPose(myroom,miregal,myExcludeBox,0);
[myrobshape,mypose] = PGPlegalRandomRobotPose(myroom,miregal,myRobo,0);
%
mydist=PGPviewDistance(mypose,mydirs,myroom,miregal);
if find(mydist<10) 
    a=sort(mydist);
    a(1:10)
    pause
end
alldist=[alldist mydist];
end
%alldist=2.*round(alldist./2);
close all;
figure(1);
hist(alldist,20);
PGPdrawScenario(myroom,miregal,myrobshape);
PGPplotBueschel(mypose,mydirs,mydist,3,':xm');
grid on;