function Rseglist = PGPpts2poly(Px,Py)
%function Rseglist = PGPpts2poly(Px,Py)
%Px == N x values
%PY == N y values
%Rseglist = [N,4] array of linesegments
N=max(4,length(Px));
Rseglist=zeros(N,4);
Rseglist(:,1)=Px(:);
Rseglist(:,2)=Py(:);
Rseglist(1:end-1,3:4)=Rseglist(2:end,1:2);
Rseglist(end,3)=Px(1);
Rseglist(end,4)=Py(1);
return;