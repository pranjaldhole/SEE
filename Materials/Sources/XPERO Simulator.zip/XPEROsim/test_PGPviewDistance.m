%test_viewDistance
%$Log$
%$Id$

clear;
close all;

robot = PGPreadPolygon('nxt_robot.txt');
mypose = [50 -70 pi/2];
%rotate and translate
PoseAngl = mypose(3);
PoseTransl = transpose(mypose(1:2));
RotTransf = [cos(PoseAngl) -sin(PoseAngl);sin(PoseAngl)  cos(PoseAngl)];
tmpArray2 = RotTransf * [transpose(robot(:,1));transpose(robot(:,2))];
curPose = tmpArray2 + repmat(PoseTransl,1,length(robot));
myrobot= PGPpts2poly(curPose(1,:),curPose(2,:));
myroom = [[-100 -100];[100 -100];[100 100];[-100 100]];
mypolyroom = PGPpts2poly(myroom(:,1),myroom(:,2));
displace = 50;
myobst = [[-10+displace -10+displace];[10+displace -10+displace];[10+displace 10+displace];[-10+displace 10+displace]];
mypolyobst{1} = PGPpts2poly(myobst(:,1),myobst(:,2));
mydirs=linspace(-pi/2,pi/2,60);
mydist=PGPviewDistance(mypose,mydirs,mypolyroom,mypolyobst);
figure(1);
hist(gca,mydist,120);
PGPdrawScenario(mypolyroom,mypolyobst,myrobot);
PGPplotBueschel(mypose,mydirs,mydist,1,':xm');
