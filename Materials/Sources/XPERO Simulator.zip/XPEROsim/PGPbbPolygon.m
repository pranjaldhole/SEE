function Rret = PGPbbPolygon(P_poly)
% [minX,maxX,minY,maxY]=bbpolygon(Poly)
% find bounding box of Poly (format: [N,4] lines segs)

allx=P_poly(:,1);
ally=P_poly(:,2);
Rret = zeros(1,4);
Rret(1) = min(allx);
Rret(2) = max(allx);
Rret(3) = min(ally);
Rret(4) = max(ally);
return