function PGPdrawScenario(Pcage,Pboxes,Probot)
%function PGPdrawScenario(Pcage,Pboxes,Probot)
% OUT: returns a handle to a figure
% IN: Pcage is a [N,2] array of points, taken as simply connected polygon (i.e
%     no holes, no selfintersection, but not necessarily convex. Last
%     point need not be duplicated, function does closing automatically
% IN: Pboxes is a cell array of K polygons (all array [KNi,2], might be empty)
% IN: Probot is the outer hull shape of a robot ([M,2] array polygon)

allrobx=Probot(:,1);
allroby=Probot(:,2);
allx=Pcage(:,1);
ally=Pcage(:,2);

[allminX,allmaxX,allminY,allmaxY]=bbpolygon(Pcage);
dimX=allmaxX-allminX;
dimY=allmaxY-allminY;
[robminX,robmaxX,robminY,robmaxY]=bbpolygon(Probot);
roballmax=max(robmaxX-robminX,robmaxY-robminY);
figure(2);
drawPolygon(allx,ally,'bd-');
axis([allminX-roballmax allmaxX+roballmax allminY-roballmax allmaxY+roballmax]);
hold on;
axis equal;
drawPolygon(allrobx,allroby,'ro-');
for k=1:length(Pboxes)
        curpoly = Pboxes{k};
        curpolyx = curpoly(:,1);
        curpolyy = curpoly(:,2);
        drawPolygon(curpolyx,curpolyy,'gd-');
end
return