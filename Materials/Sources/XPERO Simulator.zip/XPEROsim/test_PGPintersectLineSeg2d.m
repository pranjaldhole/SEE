%test_intersectLineSeg2d
%$Log$
%$Id$
%global setup
clear;
close;
clear global;
testname     = 'intersectLineSeg2d';

%setup test 1
%
testnumber   = 1;
fprintf('Start:<%s> No.<%d>: ',testname,testnumber)
% a test ray diagonal , begins : lower left
myray=[0 0 1 1];
mylines=[0 4 4 0; 2 0 2 1 ; -2 0 -2 -1 ; 0 1 1 2; 3 3 4 4];
myexpecteddist=[2*sqrt(2);2*sqrt(2);-1;-1;3*sqrt(2)];
%reguar, regular, no intersection (ray is ORIENTED!), parallel, identical 
myexpectedcase=[0;2;4;4;3];
%do test
[closestPtDist,isEqorParal] = PGPintersectLineSeg2d(myray,mylines);
%check test result
%return value1 is wrong
if find(abs(isEqorParal - myexpectedcase) > eps)%return value1 is wrong
	 fprintf('\n%s: Test No. %d ERROR: some case differs from expected ',testname,testnumber);
     isEqorParal
     return;
%return value2 is wrong
elseif find(abs(closestPtDist - myexpecteddist) > 10*eps) %catch some round off errors
	 fprintf('\n%s: Test No. %d ERROR: some distance differs from expected ',testname,testnumber);
     closestPtDist-myexpecteddist
     return;
%all OK
else    
  fprintf('OK\n',testname,testnumber);
  testnumber = testnumber+1;
end
%tear down test
clear myray;
clear mylines;
clear myexpecteddist;
clear myexpectedcase;

%setup test 2
testnumber   = 2;
fprintf('Start:<%s> No.<%d>: ',testname,testnumber)
% a test ray diagonal , begins : lower left
myray=[0 0 1 0];
mylines=[-10 -10 10 -10;10 -10 10 10;10 10 -10 10;-10 10 -10 -10];
myexpectedcase=[4;0;4;4];
%reguar, regular, no intersection (ray is ORIENTED!), parallel, identical 
myexpecteddist=[-1;10;-1;-1];
%do test
[closestPtDist,isEqorParal] = PGPintersectLineSeg2d(myray,mylines);
%check test result
%return value1 is wrong
if find(abs(isEqorParal - myexpectedcase) > eps)%return value1 is wrong
	 fprintf('\n%s: Test No. %d ERROR: some case differs from expected',testname,testnumber);
     isEqorParal
     return;
%return value2 is wrong
elseif find(abs(closestPtDist - myexpecteddist) > 10*eps) %catch some round off errors
	 fprintf('\n%s: Test No. %d ERROR: some distance differs from expected',testname,testnumber);
     closestPtDist-myexpecteddist
     return;
%all OK
else    
  fprintf('OK\n',testname,testnumber);
  testnumber = testnumber+1;
end
%tear down test
clear myray;
clear mylines;
clear myexpecteddist;
clear myexpectedcase;

%%%%%%%%%
fprintf('EOT:<%s>\n',testname)
%EOT all
