function R_ret = PGPcentroid(Ppolyg)
%function [area,cx,cy] = PGPcentroid(Ppoly)
%Ppoly of type [N,4], each row a line segment
n=size(Ppolyg,1);
px=Ppolyg(:,1);
px(end+1)=Ppolyg(1,1);
py=Ppolyg(:,2);
py(end+1)=Ppolyg(1,2);
R_ret=zeros(1,3);
skew = px(1:n).*py(2:n+1) - px(2:n+1).*py(1:n);
area = 0.5*sum(skew);
cx = dot( px(1:n)+px(2:n+1) , skew );
cx = 1/(6*area) * cx ;
cy = dot( py(1:n)+py(2:n+1) , skew );
cy = 1/(6*area) * cy;
R_ret(1)=area;
R_ret(2)=cx;
R_ret(3)=cy;
return
