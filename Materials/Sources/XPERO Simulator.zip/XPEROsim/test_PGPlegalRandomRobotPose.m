clear;
close;
myBox = PGPreadPolygon('cage.txt'); % all in cms
myExcludeBox = PGPreadPolygon('blackbox1.txt');
myRobo = PGPreadPolygon('nxt_robot.txt');
%
%miregal{1}=readPolygon('blackbox1.txt');
%miregal{2}=readPolygon('blackbox2.txt');
%miregal{3}=readPolygon('redbox.txt');
%miregal{4}=readPolygon('greenbox.txt');
%miregal{5}=readPolygon('bluebox.txt');
miregal={};

miregal{1}=PGPlegalRandomRobotPose(myBox,miregal,myExcludeBox,0);
miregal{2}=PGPlegalRandomRobotPose(myBox,miregal,myExcludeBox,0);
miregal{3}=PGPlegalRandomRobotPose(myBox,miregal,myExcludeBox,0);
miregal{4}=PGPlegalRandomRobotPose(myBox,miregal,myExcludeBox,0);
miregal{5}=PGPlegalRandomRobotPose(myBox,miregal,myExcludeBox,0);

PGPlegalRandomRobotPose(myBox,miregal,myRobo,2);
%miregal{1}=PGPlegalRandomRobotPose(myBox,miregal,myExcludeBox);
display('EOT');
