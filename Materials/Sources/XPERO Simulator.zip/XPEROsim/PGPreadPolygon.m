function polys = PGPreadPolygon(filename)
%PGPREADPOLYGON read a polygon stored in a file
% returns a [N,4] matrix of line segments [x1 y1 x2 y2]  
%

polys = zeros(0,4);
p=0;

fid = fopen(filename, 'rt');
line1(1)=' ';

while true    
    line1=fgetl(fid);
    % break loop if reach end of file
    if line1 == -1, break, end        
    % break loop if not a text line
    if ~ischar(line1), break, end
    % ignore comments
    if line1(1) == '%', continue, end
       
    p = p+1;
    %%%% PGP HACK 
    temp = [str2num(line1)]; % PGP Hack
	if (size(temp)~=[1 4])
	 fprintf(2,'error: line <%d>:<%s> does not describe a line segment (need a 4-tupple)\n',p,line1);
	 return;
    end
	polys(p,:) = temp; 
    %%%%% PGP HACK
end    
fclose(fid);
return;
