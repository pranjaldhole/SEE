function [varargout] = PGPintersectLineSeg2d(Pray,Plines)
%function [RclosestPtDist,RisEqorParal] = PGPintersectLineSeg2d(Pray,Plines)
%
%checks if the ray starting from Pray1->Pray2 and then to infinity
%will intersect some of the lines which are given by
%the segments Pline3i->Pline4i (both ways infinit, i=1...N)
%
%i.e. solve Pa  = Pray1   + ua*(Pray2-Pray1)
%and        Pbi = Pline3i + ub*(Pline4i -Pline3i) (ua and ub unknowns).
%
%Pa is directed (i.e. we must have ua >=0, pts with
%ua < 0 *do not* belong to ray). We distinguish regular and error cases
%like: identical, parallel etc
%
%IN: Pray contains directed rays from Pray1(x1,y1) to Pray2(x2,y2),
%    format of Pray is one line segment, i.e. [x1 y1 x2 y2] 
%IN: Plines contains N directed rays from P3i(x3i,y3i) to P4i(x4i,y4i)
%    format is MANY line segments in an array, i.e. size(Plines) = [N,4].
%OUT: RisEqPa is an N-dim vector of flags:
%     0 <==> Pray intersects i-th Pline between P3 and P4 (regular case)
%     1 <==> Pray intersects i-th Pline "left" of P3 (i.e. negative ub) 
%     2 <==> Pray intersects i-th Pline "right" of P4 (i.e. ub > 1) 
%     3 <==> Pray NO unique intersect: is equal to i-th Pline
%     4 <==> Pray NO intersect: is parallel to i-th Pline, or ray points the wrong way
%OUT: Rdist is an N-dim vector of norm2 distances:
%     case 0,1,2: distance to intersection point on Plines 
%     case 3:  distance from Pray1 to either Pline3 or Pline4 (whatever is closest)
%     case 4: -1 (error)

% Process inputs and do error-checking
if (nargout ~= 2)
   error('MATLAB:PGPintersectLineSeg2d:TooManyOutputs', 'Too many or few output arguments.')
end
%%init vars
N=length(Plines(:,1));
Rdist=ones(N,1);
x1vect=Pray(1)*Rdist;
y1vect=Pray(2)*Rdist;
x2vect=Pray(3)*Rdist;
y2vect=Pray(4)*Rdist;
x3vect=Plines(:,1);
y3vect=Plines(:,2);
x4vect=Plines(:,3);
y4vect=Plines(:,4);
%%init return vars
RisEqPa=Rdist*4;
Rdist=-1*Rdist;
%% start algo
%
%CASE lines are parallel: if denominator == 0, 
denominator = (x4vect-x3vect).*(y2vect-y1vect)-(x2vect-x1vect).*(y4vect-y3vect);
parallelCandi = find(abs(denominator)<10*eps); %which are zero ie. parallel ?
RisEqPa(parallelCandi)=4;%set case
Rdist(parallelCandi)=-1;
goodones=setdiff((1:N),parallelCandi);
%
%
% HACK HACK HACK I cannot deduce why the (-1) *MUST* be there for ub!
% all testcases will fail without it ?!??!
% PGP
nominatorub = (-1)*((x3vect-x1vect).*(y2vect-y1vect)-(x2vect-x1vect).*(y3vect-y1vect));
nominatorua = (x4vect-x3vect).*(y3vect-y1vect)-(x3vect-x1vect).*(y4vect-y3vect);

%CASE coincide: return dist to point (P3 or P4) whichever is closest?
coincidentCandi=find(abs(nominatorub)<10*eps); %which rays are indentical?
RisEqPa(coincidentCandi)=3;
Rdist(coincidentCandi)=...
    min(sqrt(...
        (x1vect(coincidentCandi)-x3vect(coincidentCandi)).^2+...
        (y1vect(coincidentCandi)-y3vect(coincidentCandi)).^2)...
            ,...
        sqrt(...
        (x1vect(coincidentCandi)-x4vect(coincidentCandi)).^2+...
        (y1vect(coincidentCandi)-y4vect(coincidentCandi)).^2)...
        );
goodones=setdiff(goodones,coincidentCandi);

%CASE (almost) regular:
ub=zeros(N,1);
ua=zeros(N,1);
ub(goodones)=nominatorub(goodones)./denominator(goodones);
ua(goodones)=nominatorua(goodones)./denominator(goodones);

%CASE last bad one: ray points the wrong way => NO intersect
wrongdir = find(ua<0.0);
RisEqPa(wrongdir)=4;
Rdist(wrongdir)=-1;
goodones=setdiff(goodones,wrongdir); 

%partitioning of goodones: 3 sub-cases  
leftof=find(ub < 0.0);
rightof=find(ub > 1.0);
regular=setdiff(goodones,union(leftof,rightof));
%
RisEqPa(regular)=0;
RisEqPa(intersect(leftof,goodones))=1;
RisEqPa(intersect(rightof,goodones))=2;
%
Rdist(goodones)=abs(ua(goodones)*norm([Pray(1)-Pray(3),Pray(2)-Pray(4)],2));
varargout{1} = Rdist;
varargout{2} = RisEqPa;
%todo Rdist(case 3);
return;
