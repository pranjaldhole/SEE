%$Id$
%$Log$

clear;
close;
clear global;

%setup test 1
testname     = 'PGPreadPolygon';
testnumber   = 1;
fprintf('Start:<%s> No.<%d> ',testname,testnumber)

% in file "cage.txt"
%% all in centinmeter
%0 0
%200 0
%200 200
%0 200
%%EOF
expect_box=[[0 0 200 0];[200 0 200 200];[200 200 0 200];[0 200 0 0]];

%do test
mybox = PGPreadPolygon('cage.txt');
%check
if ~isequal(mybox,expect_box)
	 fprintf('\n%s: Test No. %d ERROR: boxes not equal\n',testname,testnumber);
else
  fprintf('\n%s: Test No. %d OK\n',testname,testnumber);
  testnumber = testnumber+1;
end
%tear down
clear expect_box;
clear mybox;

%%%%%%%%%
fprintf('EOT:<%s>\n',testname)
%EOT all
