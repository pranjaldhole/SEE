function Rdist = PGPviewDistance(Ppose,Pdirections,Proom,Pobstacles)
% function Rdist = viewDistance(Ppose,Pdirections,Proom,Pobstacles)
% IN : Ppose [x(world) y(world)  alpha(rad)]: alpha==0 look straight, tune left => alpha > 0 
% IN : Pdir[1..M](rad), robot relative coords, look from (0,0) into this direction
% IN : Proom: pose lies inside a [N,2] closed polygon (closure is automatic)
% IN : Pobstacles is a cell array of Mi polygons
%      all of format [Mi,2], might be empty
% OUT: Rdist returns an array of distances Rdist random pose of P_Robot *INSIDE* P_insidePoly, not

%init vars
dim=length(Pdirections);
Rdist=-1*ones(1,dim);
minmax=zeros(1,4);
minmax=PGPbbPolygon(Proom);
radius = 2*max(minmax(2)-minmax(1),minmax(4)-minmax(3));
Palllines=zeros(0,4);
for l=1:length(Pobstacles)
    Palllines=[Palllines; Pobstacles{l}];
end    
Palllines=[Palllines; Proom];
%convert directions to points in world frame
WorldDir = Ppose(3)+Pdirections;
WorldLookToPts = transpose(repmat(Ppose(1:2).',1,dim) + radius*[cos(WorldDir);sin(WorldDir)]);
for k=1:dim %for all viewing directions
    [closestPtDist,isEqorParal] = PGPintersectLineSeg2dnew([Ppose(1:2) WorldLookToPts(k,:)],Palllines);
    candi=find(isEqorParal==0);
    try
        Rdist(k)=min(closestPtDist(candi));%hidden line removeal by taking min !!
    catch
        k
        candi
        isEqorParal
        closestPtDist
        return
    end
end
return;