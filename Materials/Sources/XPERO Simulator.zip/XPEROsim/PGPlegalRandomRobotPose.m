function [Rshape,Rpose] = PGPlegalRandomRobotPose(Pcage,Pboxes,Probot,Pdebug)
%function [Rshape,Rpose] = PGPlegalRandomRobotPose(Pcage,Pboxes,Probot,Pdebug)
% OUT: returns in Rshape a transl / rotated shape of Probot which lies *INSIDE* Pcage, not
% intersecting any of Pboxes (which are arbitrary polygons inside Pcage)
% OUT: Rpose is [cx,cy,alpha]
% IN: Pcage is a [N,4] array of line segs. taken as simply connected polygon (i.e
%     no holes, no selfintersection, but not necessarily convex.
% IN: Pboxes is a cell array of K polygons (all array [KNi,4], might be empty)
% IN: Probot is the outer hull shape of a robot ([M,4] array polygon)
% IN: Pdebug ==0 (silent), ==1 printer iter count, >1 print all

R_iter=0; % how often did we try?
allrobx=Probot(:,1);
allroby=Probot(:,2);
allx=Pcage(:,1);
ally=Pcage(:,2);

tmpresu=PGPbbPolygon(Pcage);
allminX=tmpresu(1);
allmaxX=tmpresu(2);
allminY=tmpresu(3);
allmaxY=tmpresu(4);
dimX=allmaxX-allminX;
dimY=allmaxY-allminY;
tmpresu=PGPbbPolygon(Probot);
robminX=tmpresu(1);
robmaxX=tmpresu(2);
robminY=tmpresu(3);
robmaxY=tmpresu(4);
roballmax=max(robmaxX-robminX,robmaxY-robminY);

mytmp = PGPcentroid(Pcage);

trynewandtest=true; %flag to continue searching
while (trynewandtest)
    R_iter=R_iter+1;
    %generate random pose
    rndPoseTransl = (rand(2,1)-0.5).*[dimX; dimY] + [mytmp(2);mytmp(3)];
    rndPoseAngl = 2*pi*rand(1,1);
    rndRotTransf = [cos(rndPoseAngl) -sin(rndPoseAngl);sin(rndPoseAngl)  cos(rndPoseAngl)];
    %rotate and translate
    tmpArray2 = rndRotTransf * [transpose(allrobx);transpose(allroby)];
    curPose = tmpArray2 + repmat(rndPoseTransl,1,length(tmpArray2));
    %check if we touch boundary, if YES => try next / new 
    out_in_on = inside(curPose(1,:),curPose(2,:),allx,ally);
    if min(out_in_on) == 0 %we found a robot point outside the cage
        continue;
    end
    %random pose of robot is *IN* cage 
    trynewandtest = false;
    %now test for : robot is *OUTSIDE* all exclude Polys
    for k=1:length(Pboxes)
        curpoly = Pboxes{k};
        curpolyx = curpoly(:,1);
        curpolyy = curpoly(:,2);
        out_in_on = inside(curPose(1,:),curPose(2,:),curpolyx,curpolyy);
        if max(out_in_on) > 0 %at least one lies IN or ON bdry of exclude Poly 
            % there is a robot point inside an excluded box region
            trynewandtest=true; % to continue outer loop
            break;
        end
    end
end
if Pdebug == 1 , fprintf(stderr,'iter: %d\n',R_iter); end;
if Pdebug >2 , PGPdrawScenario(Pcage,Pboxes,Probot,curPose); end;
Rshape = zeros(length(curPose),4);
Rshape(:,1:2) = transpose(curPose);
Rshape(1:end-1,3:4) = Rshape(2:end,1:2);
Rshape(end,3:4)=Rshape(1,1:2);
Rpose =[transpose(rndPoseTransl) rndPoseAngl];
return
