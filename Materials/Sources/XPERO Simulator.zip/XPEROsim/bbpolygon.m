function [R_minX,R_maxX,R_minY,R_maxY]=bbpolygon(P_poly)
% [minX,maxX,minY,maxY]=bbpolygon(Poly)
% find bounding box of Poly (format: [N,4])

allx=P_poly(:,1);
ally=P_poly(:,2);
R_minX = min(allx);
R_maxX = max(allx);
R_minY = min(ally);
R_maxY = max(ally);
return
