function [Rvfeat]=PGP_PCL_featureVal(Peigvects)
% calculate the features
% Peigvects contains featuers (ordered set of 3 eigenvals, largest first)
% retrurn the vetor of features Anisotropy:, Linearity:;Planarity:
%Sphericity:

lmax= Peigvects(1);
lmid= Peigvects(2);
lmin= Peigvects(3);

a_lam= (lmax-lmin)/lmax;
l_lam= (lmax-lmid)/lmax;
p_lam= (lmid-lmin)/lmax;
s_lam= lmin/lmax;

Rvfeat(1)=a_lam;
Rvfeat(2)=l_lam;
Rvfeat(3)=p_lam;
Rvfeat(4)=s_lam;


return

