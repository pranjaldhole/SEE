function [Rxyz] = PGP_PCL_cutOffbyPlane(Pxyz,PplanePoint,Pnormal)
% slice PCL Px,Py,Pz by plane PPoint/Pnormal
% direction of Pnormal == positive
% Px ; Py ; Pz are centered arround (0|0|0)
% Rx ; Ry ; Rz is NOT centered

%produce punkt normalen form
if (size(Pxyz,2)>size(Pxyz,1))
    error('Px,Py,Pz must be column vectors')
end
tmpboundary= dot(Pnormal,PplanePoint)*ones(length(Pxyz),1);
tmpcandi = find ( Pxyz*Pnormal > tmpboundary);
Rxyz = Pxyz(tmpcandi,:);
return

