function [Rxyz] = PGP_PCL_generateRndSphere(PrawCount,Pthick)
% generate rand points on/in a sphere of hull tickness Pthick
% Rx ;Ry, Rz are centered arround (0|0|0)
mySquare = rand(PrawCount,3);% we are in unit sphere of 1-norm.
x = [mySquare(:,1)];
y = [mySquare(:,2)];
z = [mySquare(:,3)];
cx= mean(x);
cy= mean(y);
cz= mean(z);
[azimuth,elevation,r] = cart2sph(x-cx,y-cy,z-cz);
mysph = find(r>(1/2-Pthick)&(r<1/2));
length(mysph)
[Rx,Ry,Rz] = sph2cart(azimuth(mysph),elevation(mysph),r(mysph));
Rxyz=[Rx Ry Rz];
return

