function [Rxyz] = PGP_PCL_generateRndDie(PrawCount,Pthick)
% generate rand points on/in a sphere of hull tickness Pthick
% cols of Rxyz Rx ;Ry, Rz are centered arround (0|0|0)
mySquare = rand(PrawCount,3);
x = [mySquare(:,1)];
y = [mySquare(:,2)];
z = [mySquare(:,3)];
%figure;scatter3(x,y,z)
mybnd=Pthick;
tmpx=find(x<mybnd|x>(1-mybnd));
%length(tmpx)
tmpy=find(y<mybnd|y>(1-mybnd));
%length(tmpy)
tmpz=find(z<mybnd|z>(1-mybnd));
%length(tmpz)
myuni=unique(union(tmpx,tmpy));
myuni=unique(union(myuni,tmpz));
length(myuni)
meanx=mean(x(myuni));
meany=mean(y(myuni));
meanz=mean(z(myuni));
Rxyz=[     x(myuni)-meanx];
Rxyz=[Rxyz y(myuni)-meany];
Rxyz=[Rxyz z(myuni)-meanz];
%figure;scatter3(myx,myy,myz)
return

