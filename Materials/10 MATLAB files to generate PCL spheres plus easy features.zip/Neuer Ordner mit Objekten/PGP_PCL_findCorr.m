function [Rfvect]=PGP_PCL_findCorr(Rxyz)
%function [lmay,lmid,lmin]=PGP_PCLfindCorr(Rx,Ry,Rz)
%return lambda eVals from PCL stored in the pointd from RxRyRz

N=length(Rxyz);
meanx=mean(Rxyz(:,1));
meany=mean(Rxyz(:,2));
meanz=mean(Rxyz(:,3));
myx=Rxyz(:,1)-meanx;
myy=Rxyz(:,2)-meany;
myz=Rxyz(:,3)-meanz;
%figure;scatter3(myx,myy,myz)
%
E=  [myx'*myx myx'*myy myx'*myz];
E=[E;myy'*myx myy'*myy myy'*myz];
E=[E;myz'*myx myz'*myy myz'*myz];
E=1/(N-1)*E;
[V,D]=eigs(E);
%V
%D
Rfvect(1) = D(1,1);
Rfvect(2) = D(2,2);
Rfvect(3) = D(3,3);
%Rfvect = sort(eig(E),'descend');
return

