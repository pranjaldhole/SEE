function [Rxyz] = PGP_PCL_generateRndCyl(PrawCount,Pthick)
% generate rand points on/in a sphere of hull tickness Pthick
% Rx ;Ry, Rz are centered arround (0|0|0)
mySquare = rand(PrawCount,3);
x = [mySquare(:,1)];
y = [mySquare(:,2)];
z = [mySquare(:,3)];
meanx=mean(x);
meany=mean(y);
meanz=mean(z);
x=x-meanx;
y=y-meany;
z=z-meanz;
%figure;scatter3(x,y,z)
[THETA,RHO,Z] = cart2pol(x,y,z);
tmpr=find((RHO<1/2) & (RHO>(1/2-Pthick)));
length(tmpr)
tmpz=find( ( Z<(-1/2+Pthick) ) | (Z>(1/2-Pthick)) );
tmprr=find(RHO<1/2);
%length(tmprr)
mydeckel=unique(intersect(tmpz,tmprr));
myuni=unique(union(tmpr,mydeckel));
%length(myuni)
[Rx,Ry,Rz] = pol2cart(THETA(myuni),RHO(myuni),Z(myuni));
Rxyz = [Rx Ry Rz];
%figure;scatter3(myx,myy,myz)
return

